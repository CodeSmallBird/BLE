#ifndef __KEY4X4_H__
#define __KEY4X4_H__

#include<reg52.h>
#include<intrins.h>

#include"KEY4X4.h"

void KEY4X4_Delay_1ms(unsigned int i);
void KEY4X4_delay();
unsigned char KEY4X4_Keyscan(void);

#endif